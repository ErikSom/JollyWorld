                                ........                               
                              **°°°°°°°°*                              
                            o*   °°°°°°°o                              
                           *o  **.**...oO                              
                           @ o°@ # J# # W#                             
                           #.o°   --   -*#                             
                            *O.   vvvv .O                              
                              *** °..o*°                               
                              #..*°#° .                                
                              @  # @                         .         
                   -***********°°****°°°°°°°-               *°o#****   
                   @    @      .............@*°°°°°°°°°°°°°°@*°     ** 
                  #    **     #**************ooooooooooooooo#@       @ 
                 *#    @      @#############O#@@@###########@#      .# 
                 @     #      oooooooooooooo@o***           #@@o   **  
               *#   o**#°#°°°°°°°°°°°°°°°°°°*°#              **o***    
              *#.**°*   ..                    o*                       
              @*°   *°°°O°****#*o        .o°*°O##***#*o                
             #*.*°O°o...        o#o    *O°o.....@     o#o              
           **..°o.*°#######*      o#o*#@*°O°°°°*#*      o#o            
        .*O#**o°O#@@#oooo#@@*       o@   .       @*       o#           
      .*°o**##@@@@#* O###**#@        #            @        @           
     *°.*O@@#o**#@@ °@@@@@ @#        #            #        #           
   *Oo°#@@#*.#OOo*@*.°###**@@         #           @         #          
  °oo#@@@#@ °#@@# @@#°*oo#@#@         @***********@         #          
*#oooo*##@@#* ***###@@@###@@@         #@@@@@@@@@@@@         @          
@# *O##* #@#@#O#@@@###°****#@###*****#@###########@###****#**          
#  @@@@@@ @@##@@@#O@@ °@@@# #@@#     @@@@@@@@@@@@@@@@@    #            
@*°°#@@O°*#°*o°#°*o°#*.°OO**@@#      ##############@@#    @            
*@°*.ooo*@@*.o*@*.o*@@#*oo#@oo.    o@@@@@@@@@@@@@@@oo.   **            
  .o°°°*o**o°°o*o°°o***o****°°°****o***************°°°***              
                                                                       
=======================================================================
JJJJJ OOOOO L     L     Y   Y GGGGG RRRR  OOOOO U   U N   N DDDD   SSSS
  J   O   O L     L     Y   Y G     R   R O   O U   U NN  N D   D S    
  J   O   O L     L     YYYYY G GGG RRRR  O   O U   U N N N D   D SSSSS
  J   O   O L     L       Y   G   G R   R O   O U   U N  NN D   D     S
JJJ   OOOOO LLLLL LLLLL   Y   GGGGG R   R OOOOO UUUUU N   N DDDD  SSSS 
=======================================================================
                         Everyone by Everything!                       
=======================================================================

  This is the Newgrounds Mod for JollyWorld. A full 16 character pack  
  straight from Newgrounds.com, the grandfather of internet creativity.

The full roster includes the following characters:

- Pico
from Pico's School
https://www.newgrounds.com/portal/view/310349
- Nene
from Nene Interactive Suicide
https://www.newgrounds.com/portal/view/310005
- Darnell
from Darnell Plays with Fire
https://www.newgrounds.com/portal/view/310004
by Tom Fulp, founder of Newgrounds (c. 1999).
https://tomfulp.newgrounds.com/

- Strawberry Clock and the Clock Crew - King of the Portal
from the Clock Crew (c. 2001)
https://www.newgrounds.com/collection/clockcrew

- Hank J Wimbleton
from Madness Combat 
https://www.newgrounds.com/collection/madness
by Matt "Krinkels" Jolly (c. 2002)
https://krinkels.newgrounds.com/

- Germaine and Foamy
from Neurotically Yours / Foamy the Squirrel
https://www.newgrounds.com/collection/neuroticallyyours

by Jonathan Ian (illwillpress) Mathers (c. 2001-2003)
https://illwillpress.newgrounds.com/

- Edd
from Eddsworld
https://www.newgrounds.com/collection/eddsworld
by Edd Gould (c. 2003)
https://eddsworld.newgrounds.com/

- Piconjo
https://www.newgrounds.com/collection/piconjo
from teh pr0tal (c. 2004)
https://piconjo.newgrounds.com

- Salad Fingers
https://www.newgrounds.com/collection/saladfingers
by David "Doki" Firth (c. 2004)
https://doki.newgrounds.com/

- Blockhead
https://www.newgrounds.com/collection/blockhead
by Michael "The-Swain" Swain (c. 2005)
https://the-swain.newgrounds.com/

- John Captain
from TANKMEN
https://www.newgrounds.com/collection/tankmen
by Jeff 'JohnnyUtah' Bandelin (c. 2006)
https://johnnyutah.newgrounds.com/

- Henry Stickmin
from the Henry Stickmin series
https://www.newgrounds.com/collection/henrystickmin
by Marcus "PuffballsUnited" Bromander (c. 2008)
https://puffballsunited.newgrounds.com/

- Sublo
- Tangy Mustard
from Sublo and Tangy Mustard
https://www.newgrounds.com/collection/sublotangymustard
by Aaron Long (c. 2015)
https://aaron-long.newgrounds.com/

- ENA
https://www.newgrounds.com/portal/view/756226
by Joel Guerra (c. 2020)
https://joelg.newgrounds.com/

- Olive
from Olive's Art Venture 
https://www.newgrounds.com/portal/view/830421
by Stepford, Andyl4nd, and milkypossum (c. 2022)
https://stepford.newgrounds.com/
https://andyl4nd.newgrounds.com/
https://milkypossum.newgrounds.com/

- BallFrog (as the Skippyball)
https://www.newgrounds.com/portal/view/831598
by Rhys510 and Komix (c. 2022)
https://rhys510.newgrounds.com/
https://komix.newgrounds.com/
