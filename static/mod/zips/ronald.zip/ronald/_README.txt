How to mod JollyWorld textures:

1 ) Change all the textures you would like to change
     - don't change the image width & height
     - eyes and limbs are positioned in fixed places, keep that in mind
     - (Optional) remove folders you didn't mod for faster installation
     - in the theme folder you can change the look of the preloader door;
       open the settings.json in any text editor.
       we recommend to upload a logo image to Imgur.com, make sure to 
       copy the Direct Url not an Image Link

2 ) Compress your mod to a ZIP file and give it a good name (must be zip!)
**** Make sure your zip does not contain a sub folder, but that the files are directly in the root of the zip. (So not zip > folder > content, but zip > content)

3 ) Upload the mod to https://jollyworld.app/mod

* you know what is and what isn't allowed, be mindful when spreading mods!
