How to mod JollyWorld textures:

1 ) Change all the textures you would like to change
     - don't change the image width & height
     - eyes and limbs are positioned in fixed places, keep that in mind
     - (Optional) remove folders you didn't mod for faster installation
2 ) Compress your mod to a ZIP file and give it a good name (must be zip!)
3 ) Upload the mod to https://jollyworld.app/mod

* you know what is and what isn't allowed, be mindful when spreading mods!
