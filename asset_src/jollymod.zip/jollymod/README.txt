How to mod JollyWorld textures:

1 ) Change all the textures you would like to Change
     - make sure you don't change image size
	 - eyes and limbs are positioned in fixed positions, keep that in mind
	 - you know what is and what isn't allowed, be mindful.
2 ) Option - remove all the folders you didn't mod, it will make the installation faster
3 ) Compress your mod to a zip file and give it a good name
4 ) Upload the mod to https://jollyworld.app/mod
